<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Blog Widget.
 *
 * @since 1.0
 */
class Vcard_Blog_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-blog';
	}

	public function get_title() {
		return esc_html__( 'Blog (Grid)', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'far fa-newspaper';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'h3' => __( 'H3', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			[
				'label'       => esc_html__( 'Source', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all'  => __( 'All', 'vcard-plugin' ),
					'categories' => __( 'Categories', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'source_categories',
			[
				'label'       => esc_html__( 'Source', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => $this->get_blog_categories(),
				'condition' => [
		            'source' => 'categories'
		        ],
			]
		);

		$this->add_control(
			'limit',
			[
				'label'       => esc_html__( 'Number of Items', 'vcard-plugin' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => 4,
				'default'     => 4,
			]
		);

		$this->add_control(
			'sort',
			[
				'label'       => esc_html__( 'Sorting By', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'  => __( 'Date', 'vcard-plugin' ),
					'title' => __( 'Title', 'vcard-plugin' ),
					'rand' => __( 'Random', 'vcard-plugin' ),
					'menu_order' => __( 'Order', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'       => esc_html__( 'Order', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc'  => __( 'ASC', 'vcard-plugin' ),
					'desc' => __( 'DESC', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'pagination_tab',
			[
				'label' => esc_html__( 'Pagination', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'pagination',
			[
				'label'       => esc_html__( 'Pagination Type', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'pages',
				'options' => [
					'pages' => __( 'Pagination', 'vcard-plugin' ),
					'button' => __( 'Button', 'vcard-plugin' ),
					'no' => __( 'No', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'more_btn_txt',
			[
				'label'       => esc_html__( 'Button (title)', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter button', 'vcard-plugin' ),
				'default'     => esc_html__( 'All Posts', 'vcard-plugin' ),
				'condition' => [
		            'pagination' => 'button'
		        ],
			]
		);

		$this->add_control(
			'more_btn_link',
			[
				'label'       => esc_html__( 'Button (link)', 'vcard-plugin' ),
				'type'        => Controls_Manager::URL,
				'show_external' => true,
				'condition' => [
		            'pagination' => 'button'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .section .title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_date_color',
			[
				'label'     => esc_html__( 'Date Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .news-item__date' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_date_typography',
				'label'     => esc_html__( 'Date Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .news-item__date',
			]
		);

		$this->add_control(
			'item_category_color',
			[
				'label'     => esc_html__( 'Category Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .news-item .category' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_category_typography',
				'label'     => esc_html__( 'Category Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .news-item .category',
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .news-item .title--h4' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_title_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .news-item .title--h4',
			]
		);

		$this->add_control(
			'item_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .news-item p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_text_typography',
				'label'     => esc_html__( 'Text Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .news-item p',
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render Categories List.
	 *
	 * @since 1.0
	 */
	protected function get_blog_categories() {
		$categories = [];

		$args = array(
			'type'			=> 'post',
			'child_of'		=> 0,
			'parent'		=> '',
			'orderby'		=> 'name',
			'order'			=> 'DESC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 1,
			'taxonomy'		=> 'category',
			'pad_counts'	=> false 
		);

		$blog_categories = get_categories( $args );

		foreach ( $blog_categories as $category ) {
			$categories[$category->term_id] = $category->name;
		}

		return $categories;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$this->add_inline_editing_attributes( 'title', 'basic' );

		$page_id = get_the_ID();

		$blog_slug = '#' . get_post_field( 'post_name', get_post() );

		if ( $settings['limit'] ) {
			$posts_per_page = $settings['limit'];
		} else {
			$posts_per_page = get_option( 'posts_per_page' );
		}

		if ( get_query_var( 'paged' ) ) {
		    $paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
		    $paged = get_query_var( 'page' );
		} else {
		    $paged = 1;
		}

		$posts = wp_count_posts( 'post' );
		$total_posts = $posts->publish;

		if ( $settings['source'] == 'all' ) {
			$cat_ids = '';
		} else {
			$cat_ids = $settings['source_categories'];
		}

		$args = array(
			'post_status' => 'publish',
			'post_type' => 'post',
			'orderby'			=> $settings['sort'],
			'order'				=> $settings['order'],
			'posts_per_page' => $posts_per_page,
			'paged' => $paged,
		);

		if( $settings['source'] == 'categories' ) {
			$args['cat'] = $cat_ids;
		}
		
		$q = new \WP_Query( $args );

		?>

		<div class="section">
			<?php if ( $settings['title'] ) : ?>
			<div class="pb-2">
	            <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h1 first-title title__separate">
	            	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( $settings['title'] ); ?></span>
	        	</<?php echo esc_attr( $settings['title_tag'] ); ?>>
		    </div>
		    <?php endif; ?>

		    <?php if ( $q->have_posts() ) : ?>
			<!-- News -->
			<div class="news-grid pb-0">
				<?php
				/* Start the Loop */
				while ( $q->have_posts() ) :
					$q->the_post();

					/*
					 * Include the Post-Type-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', 'grid' );

				endwhile;
				?>
			</div>

			<?php if ( $settings['pagination'] == 'pages' ) : ?>
			<div class="pagination">
				<?php
					$big = 999999999; // need an unlikely integer

					echo paginate_links( array(
						'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format' => '?paged=%#%',
						'current' => max( 1, $paged ),
						'total' => $q->max_num_pages,
						'prev_text' => esc_html__( 'Prev', 'vcard-plugin' ),
						'next_text' => esc_html__( 'Next', 'vcard-plugin' ),
						'show_all'     => false,
						'end_size'     => 1,
						'mid_size'     => 1,
						'prev_next'    => true,
						'add_args'     => false,
						'add_fragment' => $blog_slug,
					) );
				?>
			</div>
			<?php endif; ?>

			<?php if ( $settings['pagination'] == 'button' && $settings['more_btn_link'] ) : ?>
			<div class="pagination-bts text-center">
				<a class="btn" href="<?php echo esc_url( $settings['more_btn_link']['url'] ); ?>"<?php if ( $settings['more_btn_link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['more_btn_link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?>>
					<?php echo esc_html( $settings['more_btn_txt'] ); ?>		
				</a>
			</div>
			<?php endif; ?>

			<?php else :
				get_template_part( 'template-parts/content', 'none' );
			endif;

			wp_reset_postdata();

			?>
		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Blog_Widget() );