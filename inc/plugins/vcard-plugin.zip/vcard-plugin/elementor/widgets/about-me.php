<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard About Me Widget.
 *
 * @since 1.0
 */
class Vcard_About_Me_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-about-me';
	}

	public function get_title() {
		return esc_html__( 'About Me', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'far fa-user-circle';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'title_tab',
			[
				'label' => esc_html__( 'Title', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'description_tab',
			[
				'label' => esc_html__( 'Description', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'vcard-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter your description', 'vcard-plugin' ),
				'default'     => esc_html__( 'Type your description here', 'vcard-plugin' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title--h' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .section .title--h',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'description_styling',
			[
				'label'     => esc_html__( 'Description', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .single-post-text' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .section .single-post-text',
			]
		);
		
		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );
		
		?>

		<?php if ( $settings['title'] || $settings['description'] ) : ?>
		<!-- About -->
		<div class="pb-0 pb-sm-2 section">
			<?php if ( $settings['title'] ) : ?>
            <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h title--<?php echo esc_attr( $settings['title_tag'] ); ?> first-title title__separate">
            	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
					<?php echo wp_kses_post( $settings['title'] ); ?>
				</span>
            </<?php echo esc_attr( $settings['title_tag'] ); ?>>
            <?php endif; ?>
            <?php if ( $settings['description'] ) : ?>
            <div class="single-post-text">
			    <div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
		    		<?php echo wp_kses_post( $settings['description'] ); ?>		
		    	</div>
		    </div>
			<?php endif; ?>
	    </div>
	    <?php endif; ?>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'advanced' );
		#>

		<# if ( settings.title || settings.description ) { #>
		<!-- About -->
		<div class="pb-0 pb-sm-2 section">
			<# if ( settings.title ) { #>
            <{{{ settings.title_tag }}} class="title title--h title--{{{ settings.title_tag }}} first-title title__separate">
            	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
					{{{ settings.title }}}
				</span>
            </{{{ settings.title_tag }}}>
            <# } #>
            <# if ( settings.description ) { #>
            <div class="single-post-text">
			    <div {{{ view.getRenderAttributeString( 'description' ) }}}>
		    		{{{ settings.description }}}
		    	</div>
		    </div>
			<# } #>
	    </div>
	    <# } #>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_About_Me_Widget() );