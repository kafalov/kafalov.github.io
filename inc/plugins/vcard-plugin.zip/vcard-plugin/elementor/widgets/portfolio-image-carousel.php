<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Portfolio Image Carousel Widget.
 *
 * @since 1.0
 */
class Vcard_Portfolio_Image_Carousel_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-portfolio-image-carousel';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Image Carousel', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'far fa-images';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Slider Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'image',
						'label' => esc_html__( 'Image', 'vcard-plugin' ),
						'type' => Controls_Manager::MEDIA,
						'default' => [
							'url' => \Elementor\Utils::get_placeholder_image_src(),
						],
					],
					[
						'name' => 'name',
						'label'       => esc_html__( 'Name', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter name', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter name', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$theme_lightbox = get_field( 'portfolio_lightbox_disable', 'option' );

		?>

		<div class="section">
			<div class="swiper-container js-carousel-project">
				<?php if ( $settings['items'] ) : ?>
				<div class="swiper-wrapper">
					<?php foreach ( $settings['items'] as $index => $item ) : ?>
					<div class="swiper-slide swiper-slide-project">
						<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'vcard_900xAuto' ); $image_full = wp_get_attachment_image_url( $item['image']['id'], 'vcard_1920xAuto' ); ?>
						<a href="<?php echo esc_url( $image_full ); ?>"<?php if ( $theme_lightbox ) : ?> data-elementor-lightbox-slideshow="gallery" data-elementor-lightbox-title="<?php echo esc_attr( $item['name'] ); ?>"<?php else : ?> class="has-popup-image"<?php endif; ?>><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" /></a>
						<?php endif; ?>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<div class="swiper-pagination"></div>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>

		<div class="section">
			<div class="swiper-container js-carousel-project">
				<# if ( settings.items ) { #>
				<div class="swiper-wrapper">
					<# _.each( settings.items, function( item, index ) { #>
					<div class="swiper-slide swiper-slide-project">
						<# if ( item.image ) { #>
						<a href="{{{ item.image.url }}}" class="has-popup-image"><img src="{{{ item.image.url }}}" alt="{{{ item.name }}}" class="cover lazyload" /></a>
						<# } #>
					</div>
					<# }); #>
				</div>
				<# } #>
			</div>
			<div class="swiper-pagination"></div>
		</div>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Portfolio_Image_Carousel_Widget() );