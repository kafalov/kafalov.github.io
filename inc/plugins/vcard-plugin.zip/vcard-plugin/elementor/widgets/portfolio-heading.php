<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Portfolio Heading Widget.
 *
 * @since 1.0
 */
class Vcard_Portfolio_Heading_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-about-heading';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Heading', 'vcard-plugin' );
	}

	public function get_icon() {
		return ' fas fa-heading';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title_source',
			[
				'label'       => esc_html__( 'Title Source', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'  => __( 'Default', 'vcard-plugin' ),
					'custom' => __( 'Custom', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter your title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
				'condition' => [
		            'title_source' => 'custom'
		        ],
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'h3' => __( 'H3', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'image_source',
			[
				'label'       => esc_html__( 'Image Source', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'  => __( 'Default', 'vcard-plugin' ),
					'custom' => __( 'Custom', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'vcard-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
		            'image_source' => 'custom'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Content Styling', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'vcard-plugin' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'prefix_class' => 'elementor-align%s-',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .header-project .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .header-project .title',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_id = get_the_ID();

		$this->add_inline_editing_attributes( 'title', 'basic' );

		$title = get_the_title( $post_id );
		$image = get_the_post_thumbnail_url( $post_id, 'vcard_1920xAuto' );

		if ( $settings['title_source'] == 'custom' ) :
			$title = $settings['title'];
		endif;
		if ( $settings['image_source'] == 'custom' ) :
			$image = $settings['image']['url'];
		endif;

		?>

		<header class="header-project<?php if ( ! $image ) : ?> header-project-noimg<?php endif; ?>">
			<?php if ( $title ) : ?>
            <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h1 first-title title__separate">
            	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
            		<?php echo wp_kses_post( $title ); ?>
            	</span>
            </<?php echo esc_attr( $settings['title_tag'] ); ?>>
        	<?php endif; ?>
			<?php if ( $image ) : ?>
			<div class="header-project__image-wrap">
			    <img class="cover ls-is-cached lazyloaded" src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
			</div>
			<?php endif; ?>
		</header>
      
		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		var title = 'Default Post Title';
		if ( settings.title_source == 'custom' ) {
			title = settings.title;
		}
		#>

		<header class="header-project<?php if ( ! $image ) : ?> header-project-noimg<?php endif; ?>">
			<# if ( settings.title ) { #>
            <{{{ settings.title_tag }}} class="title title--h1 first-title title__separate">
            	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
            		{{{ title }}}
            	</span>
            </{{{ settings.title_tag }}}>
        	<# } #>
			<# if ( settings.image ) { #>
			<div class="header-project__image-wrap">
			    <img class="cover ls-is-cached lazyloaded" src="{{{ settings.image.url }}}" alt="" />
			</div>
			<# } #>
		</header>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Portfolio_Heading_Widget() );