<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard About Heading Widget.
 *
 * @since 1.0
 */
class Vcard_About_Headings_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-about-headings';
	}

	public function get_title() {
		return esc_html__( 'Section Heading', 'vcard-plugin' );
	}

	public function get_icon() {
		return ' fas fa-heading';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'heading_content',
			[
				'label' => esc_html__( 'Heading', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter your title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'h3' => __( 'H3', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'about_heading_styling',
			[
				'label'     => esc_html__( 'Heading', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'vcard-plugin' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'vcard-plugin' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'prefix_class' => 'elementor-align%s-',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .section .title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_spacing_styling',
			[
				'label'     => esc_html__( 'Spacing', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_padding',
			[
				'label'      => esc_html__( 'Padding', 'vcard-plugin' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		

		$this->add_control(
			'heading_margin',
			[
				'label'      => esc_html__( 'Margin', 'vcard-plugin' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );

		?>

		<?php if ( $settings['title'] ) : ?>
		<!-- About -->
		<div class="pb-3 section">
            <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--<?php echo esc_attr( $settings['title_tag'] ); ?> first-title title__separate">
            	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
            		<?php echo wp_kses_post( $settings['title'] ); ?>
            	</span>
            </<?php echo esc_attr( $settings['title_tag'] ); ?>>
	    </div>
	    <?php endif; ?>

      
		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		#>

		<# if ( settings.title ) { #>
		<!-- About -->
		<div class="pb-3 section">
            <{{{ settings.title_tag }}} class="title title--{{{ settings.title_tag }}} first-title title__separate">
            	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
            		{{{ settings.title }}}
            	</span>
            </{{{ settings.title_tag }}}>
	    </div>
	    <# } #>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_About_Headings_Widget() );