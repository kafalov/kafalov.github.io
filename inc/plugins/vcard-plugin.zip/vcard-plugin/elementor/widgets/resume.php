<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Resume Widget.
 *
 * @since 1.0
 */
class Vcard_Resume_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-resume';
	}

	public function get_title() {
		return esc_html__( 'Resume', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'far fa-address-card';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'layout_tab',
			[
				'label' => esc_html__( 'Layout', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout_count',
			[
				'label'       => esc_html__( 'Count of Col', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1'  => __( '1', 'vcard-plugin' ),
					'2' => __( '2', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'layout_col',
			[
				'label'       => esc_html__( 'Layout', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1'  => __( '1 Column', 'vcard-plugin' ),
					'2' => __( '2 Column', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col1_tab',
			[
				'label' => esc_html__( 'Content Column #1', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label'       => esc_html__( 'Icon Type', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image'  => __( 'Image', 'vcard-plugin' ),
					'font' => __( 'Font', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'icon',
			[
				'label'       => esc_html__( 'Icon', 'vcard-plugin' ),
				'type'        => Controls_Manager::ICONS,
				'condition' => [
		            'icon_type' => 'font'
		        ],
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'vcard-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
		            'icon_type' => 'image'
		        ],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'date',
						'label'       => esc_html__( 'Date', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'label_block' => true,
						'placeholder' => esc_html__( 'Enter date', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter date', 'vcard-plugin' ),
					],
					[
						'name' => 'name',
						'label'       => esc_html__( 'Title', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter title', 'vcard-plugin' ),
					],
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'vcard-plugin' ),
						'type'        => Controls_Manager::WYSIWYG,
						'placeholder' => esc_html__( 'Enter description', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter description', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col2_tab',
			[
				'label' => esc_html__( 'Content Column #2', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
		            'layout_count' => '2'
		        ],
			]
		);

		$this->add_control(
			'c2_title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'c2_title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'c2_icon_type',
			[
				'label'       => esc_html__( 'Icon Type', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image'  => __( 'Image', 'vcard-plugin' ),
					'font' => __( 'Font', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'c2_icon',
			[
				'label'       => esc_html__( 'Icon', 'vcard-plugin' ),
				'type'        => Controls_Manager::ICONS,
				'condition' => [
		            'c2_icon_type' => 'font'
		        ],
			]
		);

		$this->add_control(
			'c2_image',
			[
				'label' => esc_html__( 'Image', 'vcard-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
		            'c2_icon_type' => 'image'
		        ],
			]
		);

		$this->add_control(
			'c2_items',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'date',
						'label'       => esc_html__( 'Date', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'label_block' => true,
						'placeholder' => esc_html__( 'Enter date', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter date', 'vcard-plugin' ),
					],
					[
						'name' => 'name',
						'label'       => esc_html__( 'Title', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter title', 'vcard-plugin' ),
					],
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'vcard-plugin' ),
						'type'        => Controls_Manager::WYSIWYG,
						'placeholder' => esc_html__( 'Enter description', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter description', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title--h' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .section .title--h',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_styling',
			[
				'label'     => esc_html__( 'Icon', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_date_color',
			[
				'label'     => esc_html__( 'Date Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .timeline__item .timeline__period' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_date_typography',
				'label'     => esc_html__( 'Date Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .timeline__item .timeline__period',
			]
		);

		$this->add_control(
			'item_name_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .timeline__item .timeline__title' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_name_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .timeline__item .timeline__title',
			]
		);

		$this->add_control(
			'item_desc_color',
			[
				'label'     => esc_html__( 'Description Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .timeline__item .timeline__description' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_desc_typography',
				'label'     => esc_html__( 'Description Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .timeline__item .timeline__description',
			]
		);
		
		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'c2_title', 'basic' );

		?>

		<!-- Experience -->
		<div class="pb-0 section">
			<div class="row">
			    <div class="col-12 col-lg-6">
				    <?php if ( $settings['title'] ) : ?>
				    <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h title--h3">
				    	<?php if ( $settings['icon_type'] == 'image' ) : ?>
			        	<?php if ( $settings['image'] ) : ?>
			        	<img class="title-icon" src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="" />
			        	<?php endif; ?>
			        	<?php else :?>
			        	<?php if ( $settings['icon'] ) : ?>
					    <div class="title-icon">
					    	<?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</div>
						<?php endif; ?>
						<?php endif; ?>
				    	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
		            		<?php echo wp_kses_post( $settings['title'] ); ?>
		            	</span>
				    </<?php echo esc_attr( $settings['title_tag'] ); ?>>
				    <?php endif; ?>

				    <?php if ( $settings['items'] ) : ?>
					<div class="timeline">
						<?php foreach ( $settings['items'] as $index => $item ) : 
									
						    $item_date = $this->get_repeater_setting_key( 'date', 'items', $index );
						    $this->add_inline_editing_attributes( $item_date, 'none' );

						    $item_name = $this->get_repeater_setting_key( 'name', 'items', $index );
						    $this->add_inline_editing_attributes( $item_name, 'basic' );

						    $item_desc = $this->get_repeater_setting_key( 'desc', 'items', $index );
						    $this->add_inline_editing_attributes( $item_desc, 'advanced' );

						?>
					    <!-- Item -->
					    <article class="timeline__item">
					    	<?php if ( $item['name'] ) : ?>
					        <h5 class="title title--h5 timeline__title">
					        	<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
									<?php echo wp_kses_post( $item['name'] ); ?>
								</span>
					        </h5>
					        <?php endif; ?>
						    <?php if ( $item['date'] ) : ?>
						    <span class="timeline__period">
						    	<span <?php echo $this->get_render_attribute_string( $item_date ); ?>>
									<?php echo esc_html( $item['date'] ); ?>
								</span>
						    </span>
						    <?php endif; ?>
						    <?php if ( $item['desc'] ) : ?>
						    <div class="timeline__description">
						    	<div <?php echo $this->get_render_attribute_string( $item_desc ); ?>>
									<?php echo wp_kses_post( $item['desc'] ); ?>
								</div>
						    </div>
						    <?php endif; ?>
						</article>
		                <?php endforeach; ?>
					</div>
					<?php endif; ?>
				</div>
				
				<?php if ( $settings['layout_count'] == '2' ) : ?>
			    <div class="col-12 <?php if ( $settings['layout_col'] == '2' ) : ?>col-lg-6<?php endif; ?>">
				    <?php if ( $settings['c2_title'] ) : ?>
				    <<?php echo esc_attr( $settings['c2_title_tag'] ); ?> class="title title--h title--h3">
				    	<?php if ( $settings['c2_icon_type'] == 'image' ) : ?>
			        	<?php if ( $settings['c2_image'] ) : ?>
			        	<img class="title-icon" src="<?php echo esc_url( $settings['c2_image']['url'] ); ?>" alt="" />
			        	<?php endif; ?>
			        	<?php else :?>
			        	<?php if ( $settings['c2_icon'] ) : ?>
					    <div class="title-icon">
					    	<?php \Elementor\Icons_Manager::render_icon( $settings['c2_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</div>
						<?php endif; ?>
						<?php endif; ?>
				    	<span <?php echo $this->get_render_attribute_string( 'c2_title' ); ?>>
		            		<?php echo wp_kses_post( $settings['c2_title'] ); ?>
		            	</span>
				    </<?php echo esc_attr( $settings['c2_title_tag'] ); ?>>
				    <?php endif; ?>

				    <?php if ( $settings['c2_items'] ) : ?>
					<div class="timeline">
						<?php foreach ( $settings['c2_items'] as $index => $item ) : 
									
						    $item_date = $this->get_repeater_setting_key( 'date', 'c2_items', $index );
						    $this->add_inline_editing_attributes( $item_date, 'none' );

						    $item_name = $this->get_repeater_setting_key( 'name', 'c2_items', $index );
						    $this->add_inline_editing_attributes( $item_name, 'basic' );

						    $item_desc = $this->get_repeater_setting_key( 'desc', 'c2_items', $index );
						    $this->add_inline_editing_attributes( $item_desc, 'advanced' );

						?>
					    <!-- Item -->
					    <article class="timeline__item">
					    	<?php if ( $item['name'] ) : ?>
					        <h5 class="title title--h5 timeline__title">
					        	<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
									<?php echo wp_kses_post( $item['name'] ); ?>
								</span>
					        </h5>
					        <?php endif; ?>
						    <?php if ( $item['date'] ) : ?>
						    <span class="timeline__period">
						    	<span <?php echo $this->get_render_attribute_string( $item_date ); ?>>
									<?php echo esc_html( $item['date'] ); ?>
								</span>
						    </span>
						    <?php endif; ?>
						    <?php if ( $item['desc'] ) : ?>
						    <div class="timeline__description">
						    	<div <?php echo $this->get_render_attribute_string( $item_desc ); ?>>
									<?php echo wp_kses_post( $item['desc'] ); ?>
								</div>
						    </div>
						    <?php endif; ?>
						</article>
		                <?php endforeach; ?>
					</div>
					<?php endif; ?>
				</div>
				<?php endif; ?>

			</div>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		var iconHTML = elementor.helpers.renderIcon( view, settings.icon, { 'aria-hidden': true }, 'i' , 'object' );

		view.addInlineEditingAttributes( 'c2_title', 'basic' );
		var c2_iconHTML = elementor.helpers.renderIcon( view, settings.c2_icon, { 'aria-hidden': true }, 'i' , 'object' );
		#>

		<!-- Experience -->
		<div class="pb-0 section">
			<div class="row">
			    <div class="col-12 col-lg-6">
				    <# if ( settings.title ) { #>
				    <{{{ settings.title_tag }}} class="title title--h title--h3">
				    	<# if ( settings.icon_type == 'image' ) { #>
			        	<# if ( settings.image ) { #>
			        	<img class="title-icon" src="{{{ settings.image.url }}}" alt="" />
			        	<# } #>
			        	<# } else { #>
			        	<# if ( settings.icon ) { #>
					    <div class="title-icon">
					    	{{{ iconHTML.value }}}
						</div>
						<# } #>
						<# } #>
				    	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
		            		{{{ settings.title }}}
		            	</span>
				    </{{{ settings.title_tag }}}>
				    <# } #>

				    <# if ( settings.items ) { #>
					<div class="timeline">
						<# _.each( settings.items, function( item, index ) { 

						    var item_date = view.getRepeaterSettingKey( 'date', 'items', index );
						    view.addInlineEditingAttributes( item_date, 'none' );

						    var item_name = view.getRepeaterSettingKey( 'name', 'items', index );
						    view.addInlineEditingAttributes( item_name, 'basic' );

						    var item_desc = view.getRepeaterSettingKey( 'desc', 'items', index );
						    view.addInlineEditingAttributes( item_desc, 'advanced' );

						#>
					    <!-- Item -->
					    <article class="timeline__item">
					    	<# if ( item.name ) { #>
					        <h5 class="title title--h5 timeline__title">
					        	<span {{{ view.getRenderAttributeString( item_name ) }}}>
									{{{ item.name }}}
								</span>
					        </h5>
					        <# } #>
						    <# if ( item.date ) { #>
						    <span class="timeline__period">
						    	<span {{{ view.getRenderAttributeString( item_date ) }}}>
									{{{ item.date }}}
								</span>
						    </span>
						    <# } #>
						    <# if ( item.desc ) { #>
						    <div class="timeline__description">
						    	<div {{{ view.getRenderAttributeString( item_desc ) }}}>
									{{{ item.desc }}}
								</div>
						    </div>
						    <# } #>
						</article>
		                <# }); #>
					</div>
					<# } #>
				</div>
				
				<# if ( settings.layout_count == '2' ) { #>
			    <div class="col-12 <# if ( settings.layout_col == '2' ) { #>col-lg-6<# } #>">
				    <# if ( settings.c2_title ) { #>
				    <{{{ settings.c2_title_tag }}} class="title title--h title--h3">
				    	<# if ( settings.c2_icon_type == 'image' ) { #>
			        	<# if ( settings.c2_image ) { #>
			        	<img class="title-icon" src="{{{ settings.c2_image.url }}}" alt="" />
			        	<# } #>
			        	<# } else { #>
			        	<# if ( settings.c2_icon ) { #>
					    <div class="title-icon">
					    	{{{ c2_iconHTML.value }}}
						</div>
						<# } #>
						<# } #>
				    	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
		            		{{{ settings.c2_title }}}
		            	</span>
				    </{{{ settings.c2_title_tag }}}>
				    <# } #>

				    <# if ( settings.c2_items ) { #>
					<div class="timeline">
						<# _.each( settings.c2_items, function( item, index ) { 

						    var item_date = view.getRepeaterSettingKey( 'date', 'c2_items', index );
						    view.addInlineEditingAttributes( item_date, 'none' );

						    var item_name = view.getRepeaterSettingKey( 'name', 'c2_items', index );
						    view.addInlineEditingAttributes( item_name, 'basic' );

						    var item_desc = view.getRepeaterSettingKey( 'desc', 'c2_items', index );
						    view.addInlineEditingAttributes( item_desc, 'advanced' );

						#>
					    <!-- Item -->
					    <article class="timeline__item">
					    	<# if ( item.name ) { #>
					        <h5 class="title title--h5 timeline__title">
					        	<span {{{ view.getRenderAttributeString( item_name ) }}}>
									{{{ item.name }}}
								</span>
					        </h5>
					        <# } #>
						    <# if ( item.date ) { #>
						    <span class="timeline__period">
						    	<span {{{ view.getRenderAttributeString( item_date ) }}}>
									{{{ item.date }}}
								</span>
						    </span>
						    <# } #>
						    <# if ( item.desc ) { #>
						    <div class="timeline__description">
						    	<div {{{ view.getRenderAttributeString( item_desc ) }}}>
									{{{ item.desc }}}
								</div>
						    </div>
						    <# } #>
						</article>
		                <# }); #>
					</div>
					<# } #>
				</div>
				<# } #>

			</div>
		</div>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Resume_Widget() );