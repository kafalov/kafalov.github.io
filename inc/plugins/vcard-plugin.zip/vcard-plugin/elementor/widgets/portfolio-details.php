<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Portfolio Details Widget.
 *
 * @since 1.0
 */
class Vcard_Portfolio_Details_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-portfolio-details';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Details', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'fas fa-clipboard-list';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Details Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'label',
						'label'       => esc_html__( 'Label', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter label', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Label', 'vcard-plugin' ),
					],
					[
						'name' => 'value',
						'label'       => esc_html__( 'Value', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter value', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Value', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items Styling', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .details-info__item .overhead' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_title_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .details-info__item .overhead',
			]
		);

		$this->add_control(
			'item_value_color',
			[
				'label'     => esc_html__( 'Value Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .details-info__item .value-text' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_value_typography',
				'label'     => esc_html__( 'Value Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .details-info__item .value-text',
			]
		);
		
		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="pb-0 pb-sm-2 section">
			<?php if ( $settings['items'] ) : ?>
			<ul class="details-info details-info--inline">
				<?php foreach ( $settings['items'] as $index => $item ) : 
				    $item_label = $this->get_repeater_setting_key( 'label', 'items', $index );
				    $this->add_inline_editing_attributes( $item_label, 'basic' );

				    $item_value = $this->get_repeater_setting_key( 'value', 'items', $index );
				    $this->add_inline_editing_attributes( $item_value, 'basic' );
				?>
				<li class="details-info__item">
					<div class="details-info__info">
						<?php if ( $item['label'] ) : ?>
						<span class="overhead">
							<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
								<?php echo wp_kses_post( $item['label'] ); ?>
							</span>
						</span>
						<?php endif; ?>
						<?php if ( $item['value'] ) : ?>
						<span class="value-text">
							<span <?php echo $this->get_render_attribute_string( $item_value ); ?>>
								<?php echo wp_kses_post( $item['value'] ); ?>
							</span>
						</span>
						<?php endif; ?>
					</div>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php endif; ?>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		
		<div class="pb-0 pb-sm-2 section">
			<# if ( settings.items ) { #>
			<ul class="details-info details-info--inline">
				<# _.each( settings.items, function( item, index ) {
				    var item_label = view.getRepeaterSettingKey( 'label', 'items', index );
				    view.addInlineEditingAttributes( item_label, 'basic' );

				    var item_value = view.getRepeaterSettingKey( 'value', 'items', index );
				    view.addInlineEditingAttributes( item_value, 'advanced' );
				#>
				<li class="details-info__item">
					<div class="details-info__info">
						<# if ( item.label ) { #>
						<span class="overhead">
							<span {{{ view.getRenderAttributeString( item_label ) }}}>
								{{{ item.label }}}
							</span>
						</span>
						<# } #>
						<# if ( item.value ) { #>
						<span class="value-text">
							<span {{{ view.getRenderAttributeString( item_value ) }}}>
								{{{ item.value }}}
							</span>
						</span>
						<# } #>
					</div>
				</li>
				<# }); #>
			</ul>
			<# } #>
		</div>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Portfolio_Details_Widget() );