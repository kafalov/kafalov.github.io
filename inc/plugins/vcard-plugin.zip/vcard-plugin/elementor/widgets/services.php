<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Services Widget.
 *
 * @since 1.0
 */
class Vcard_Services_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-services';
	}

	public function get_title() {
		return esc_html__( 'Services', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'fas fa-concierge-bell';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'title_tab',
			[
				'label' => esc_html__( 'Title', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Services Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'icon_type',
						'label'       => esc_html__( 'Icon Type', 'vcard-plugin' ),
						'type'        => Controls_Manager::SELECT,
						'default' => 'image',
						'options' => [
							'image'  => __( 'Image', 'vcard-plugin' ),
							'font' => __( 'Font', 'vcard-plugin' ),
						],
					],
					[
						'name' => 'image',
						'label' => esc_html__( 'Image', 'vcard-plugin' ),
						'type' => Controls_Manager::MEDIA,
						'default' => [
							'url' => \Elementor\Utils::get_placeholder_image_src(),
						],
						'condition' => [
				            'icon_type' => 'image'
				        ],
					],
					[
						'name' => 'icon',
						'label'       => esc_html__( 'Icon', 'vcard-plugin' ),
						'type'        => Controls_Manager::ICONS,
						'condition' => [
				            'icon_type' => 'font'
				        ],
					],
					[
						'name' => 'name',
						'label'       => esc_html__( 'Title', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter title', 'vcard-plugin' ),
					],
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXTAREA,
						'placeholder' => esc_html__( 'Enter description', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Enter description', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title--h' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .section .title--h',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .case-item .case-item__icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .case-item .title' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_title_typography',
				'label'     => esc_html__( 'Title Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .case-item .title',
			]
		);

		$this->add_control(
			'item_desc_color',
			[
				'label'     => esc_html__( 'Description Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .case-item .case-item__caption' => 'color: {{VALUE}};',
				],
			]
		);		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_desc_typography',
				'label'     => esc_html__( 'Description Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .case-item .case-item__caption',
			]
		);
		
		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );
		?>


		<!-- What -->
		<div class="box-inner pb-0 section">
			<?php if ( $settings['title'] ) : ?>
		    <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h title--h3">
		    	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
            		<?php echo wp_kses_post( $settings['title'] ); ?>
            	</span>
		    </<?php echo esc_attr( $settings['title_tag'] ); ?>>
		    <?php endif; ?>

		    <?php if ( $settings['items'] ) : ?>
			<div class="row">
			 	<?php foreach ( $settings['items'] as $index => $item ) : 
				    $item_name = $this->get_repeater_setting_key( 'name', 'items', $index );
				    $this->add_inline_editing_attributes( $item_name, 'basic' );

				    $item_desc = $this->get_repeater_setting_key( 'desc', 'items', $index );
				    $this->add_inline_editing_attributes( $item_desc, 'basic' );
				?>
			    <!-- Case Item -->
			    <div class="col-12 col-lg-6">
			        <div class="case-item box box__second">
			        	<?php if ( $item['icon_type'] == 'image' ) : ?>
			        	<?php if ( $item['image'] ) : ?>
			        	<img class="case-item__icon" src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="" />
			        	<?php endif; ?>
			        	<?php else :?>
			        	<?php if ( $item['icon'] ) : ?>
					    <div class="case-item__icon">
					    	<?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</div>
						<?php endif; ?>
						<?php endif; ?>
						<div>
							<?php if ( $item['name'] ) : ?>
					        <h3 class="title title--h5">
					        	<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
									<?php echo wp_kses_post( $item['name'] ); ?>
								</span>
					        </h3>
					    	<?php endif; ?>
					    	<?php if ( $item['desc'] ) : ?>
						    <p class="case-item__caption">
						    	<span <?php echo $this->get_render_attribute_string( $item_desc ); ?>>
									<?php echo wp_kses_post( $item['desc'] ); ?>
								</span>
						    </p>
							<?php endif; ?>
						</div>	
					</div>
				</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		#>

		<!-- What -->
		<div class="box-inner pb-0">
			<# if ( settings.title ) { #>
		    <{{{ settings.title_tag }}} class="title title--h title--h3">
		    	<span {{{ view.getRenderAttributeString( 'title' ) }}}>
            		{{{ settings.title }}}
            	</span>
		    </{{{ settings.title_tag }}}>
		    <# } #>

		    <# if ( settings.items ) { #>
			<div class="row">
			 	<# _.each( settings.items, function( item, index ) { 

				    var item_name = view.getRepeaterSettingKey( 'name', 'items', index );
				    view.addInlineEditingAttributes( item_name, 'basic' );

				    var item_desc = view.getRepeaterSettingKey( 'desc', 'items', index );
				    view.addInlineEditingAttributes( item_desc, 'advanced' );

				    var iconHTML = elementor.helpers.renderIcon( view, item.icon, { 'aria-hidden': true }, 'i' , 'object' );
				#>
			    <!-- Case Item -->
			    <div class="col-12 col-lg-6">
			        <div class="case-item box box__second">
						<# if ( item.icon_type == 'image' ) { #>
			        	<# if ( item.image ) { #>
			        	<img class="case-item__icon" src="{{{ item.image.url }}}" alt="" />
			        	<# } #>
			        	<# } else { #>
			        	<# if ( item.icon ) { #>
					    <div class="case-item__icon">
					    	{{{ iconHTML.value }}}
						</div>
						<# } #>
						<# } #>
						<div>
							<# if ( item.name ) { #>
					        <h3 class="title title--h5">
					        	<span {{{ view.getRenderAttributeString( item_name ) }}}>
									{{{ item.name }}}
								</span>
					        </h3>
					    	<# } #>
					    	<# if ( item.desc ) { #>
						    <p class="case-item__caption">
						    	<span {{{ view.getRenderAttributeString( item_desc ) }}}>
									{{{ item.desc }}}
								</span>
						    </p>
							<# } #>
						</div>	
					</div>
				</div>
				<# }); #>
			</div>
			<# } #>
		</div>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Services_Widget() );