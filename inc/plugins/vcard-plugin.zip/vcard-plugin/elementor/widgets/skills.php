<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Vcard Skills Widget.
 *
 * @since 1.0
 */
class Vcard_Skills_Widget extends Widget_Base {

	public function get_name() {
		return 'vcard-skills';
	}

	public function get_title() {
		return esc_html__( 'Skills', 'vcard-plugin' );
	}

	public function get_icon() {
		return 'fas fa-dumbbell';
	}

	public function get_categories() {
		return [ 'vcard-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'layout_tab',
			[
				'label' => esc_html__( 'Layout', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout_count',
			[
				'label'       => esc_html__( 'Count of Col', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1'  => __( '1', 'vcard-plugin' ),
					'2' => __( '2', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'layout_col',
			[
				'label'       => esc_html__( 'Layout', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1'  => __( '1 Column', 'vcard-plugin' ),
					'2' => __( '2 Column', 'vcard-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col1_tab',
			[
				'label' => esc_html__( 'Content Column #1', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Skills Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'label',
						'label'       => esc_html__( 'Progress Label', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'placeholder' => esc_html__( '90%', 'vcard-plugin' ),
						'default'	=> esc_html__( '90%', 'vcard-plugin' ),
					],
					[
						'name' => 'value',
						'label'       => esc_html__( 'Progress Value (%)', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'placeholder' => esc_html__( '90', 'vcard-plugin' ),
						'default'	=> esc_html__( '90', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col2_tab',
			[
				'label' => esc_html__( 'Content Column #2', 'vcard-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
		            'layout_count' => '2'
		        ],
			]
		);

		$this->add_control(
			'c2_title',
			[
				'label'       => esc_html__( 'Title', 'vcard-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'vcard-plugin' ),
				'default'     => esc_html__( 'Title', 'vcard-plugin' ),
			]
		);

		$this->add_control(
			'c2_title_tag',
			[
				'label'       => esc_html__( 'Title Tag', 'vcard-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  => __( 'H1', 'vcard-plugin' ),
					'h2' => __( 'H2', 'vcard-plugin' ),
					'div' => __( 'DIV', 'vcard-plugin' ),
				],
			]
		);

		$this->add_control(
			'c2_items',
			[
				'label' => esc_html__( 'Skills Items', 'vcard-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => [
					[
						'name' => 'label',
						'label'       => esc_html__( 'Progress Label', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'placeholder' => esc_html__( 'Label', 'vcard-plugin' ),
						'default'	=> esc_html__( 'Label', 'vcard-plugin' ),
					],
					[
						'name' => 'value',
						'label'       => esc_html__( 'Progress Value (%)', 'vcard-plugin' ),
						'type'        => Controls_Manager::TEXT,
						'placeholder' => esc_html__( '90', 'vcard-plugin' ),
						'default'	=> esc_html__( '90', 'vcard-plugin' ),
					],
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .section .title',
			]
		);

		$this->end_controls_section();

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'vcard-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_progress_label_color',
			[
				'label'     => esc_html__( 'Progress Label Color', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .progress-bar' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_progress_label_typography',
				'label'     => esc_html__( 'Progress Label Typography', 'vcard-plugin' ),
				'selector' => '{{WRAPPER}} .progress-bar',
			]
		);

		$this->add_control(
			'item_progress_line_color',
			[
				'label'     => esc_html__( 'Progress Line Background', 'vcard-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .progress-bar' => 'background: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'c2_title', 'basic' );

		?>

		<!-- Skills -->
		<div class="box-inner section">
		    <div class="row">
			    <div class="col-12 col-lg-6">
			    	<?php if ( $settings['title'] ) : ?>
		            <<?php echo esc_attr( $settings['title_tag'] ); ?> class="title title--h3">
		            	<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
		            		<?php echo wp_kses_post( $settings['title'] ); ?>
		            	</span>
		            </<?php echo esc_attr( $settings['title_tag'] ); ?>>
		            <?php endif; ?>

		            <?php if ( $settings['items'] ) : ?>
					<div class="box box__second">
					    <?php foreach ( $settings['items'] as $index => $item ) : 
									
						    $item_label = $this->get_repeater_setting_key( 'label', 'items', $index );
						    $this->add_inline_editing_attributes( $item_label, 'none' );

						    $item_value = $this->get_repeater_setting_key( 'value', 'items', $index );
						    $this->add_inline_editing_attributes( $item_value, 'none' );

						?>
					    <!-- Progress -->
					    <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo esc_attr( $item['value'] ); ?>" aria-valuemin="0" aria-valuemax="100">
							    <div class="progress-text">
							    	<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
										<?php echo wp_kses_post( $item['label'] ); ?>
									</span>
							    	<span <?php echo $this->get_render_attribute_string( $item_value ); ?>>
										<?php echo wp_kses_post( $item['value'] ); ?><?php echo esc_html( '%', 'vcard-plugin' ); ?>
									</span>
							    </div>
							</div>
							<div class="progress-text">
								<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
									<?php echo wp_kses_post( $item['label'] ); ?>
								</span>
							</div>
                        </div>
                        <?php endforeach; ?>
					</div>
					<?php endif; ?>
                </div>
				
				<?php if ( $settings['layout_count'] == '2' ) : ?>
			    <div class="col-12<?php if ( $settings['layout_col'] == '2' ) : ?> col-lg-6 mt-4<?php endif; ?> mt-lg-0">
		            <?php if ( $settings['c2_title'] ) : ?>
		            <<?php echo esc_attr( $settings['c2_title_tag'] ); ?> class="title title--h3">
		            	<span <?php echo $this->get_render_attribute_string( 'c2_title' ); ?>>
		            		<?php echo wp_kses_post( $settings['c2_title'] ); ?>
		            	</span>
		            </<?php echo esc_attr( $settings['c2_title_tag'] ); ?>>
		            <?php endif; ?>

		            <?php if ( $settings['c2_items'] ) : ?>
					<div class="box box__second">
					    <?php foreach ( $settings['c2_items'] as $index => $item ) : 
									
						    $item_label = $this->get_repeater_setting_key( 'label', 'c2_items', $index );
						    $this->add_inline_editing_attributes( $item_label, 'none' );

						    $item_value = $this->get_repeater_setting_key( 'value', 'c2_items', $index );
						    $this->add_inline_editing_attributes( $item_value, 'none' );

						?>
					    <!-- Progress -->
					    <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo esc_attr( $item['value'] ); ?>" aria-valuemin="0" aria-valuemax="100">
							    <div class="progress-text">
							    	<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
										<?php echo wp_kses_post( $item['label'] ); ?>
									</span>
							    	<span <?php echo $this->get_render_attribute_string( $item_value ); ?>>
										<?php echo wp_kses_post( $item['value'] ); ?><?php echo esc_html( '%', 'vcard-plugin' ); ?>
									</span>
							    </div>
							</div>
							<div class="progress-text">
								<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
									<?php echo wp_kses_post( $item['label'] ); ?>
								</span>
							</div>
                        </div>
                        <?php endforeach; ?>
					</div>
					<?php endif; ?>
                </div>
                <?php endif; ?>
			</div>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'c2_title', 'basic' );
		#>

		<!-- Skills -->
		<div class="box-inner box-inner--rounded section">
		    <div class="row">
			    <div class="col-12 col-lg-6">
					<# if ( settings.title ) { #>
					<{{{ settings.title_tag }}} class="title title--h3">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>
							{{{ settings.title }}}
						</span>
					</{{{ settings.title_tag }}}>
					<# } #>

		            <# if ( settings.items ) { #>
					<div class="box box__second">
					    <# _.each( settings.items, function( item, index ) { 

					    	var item_label = view.getRepeaterSettingKey( 'label', 'items', index );
					    	view.addInlineEditingAttributes( item_label, 'none' );

					    	var item_value = view.getRepeaterSettingKey( 'value', 'items', index );
					    	view.addInlineEditingAttributes( item_value, 'none' );

					    #>
					    <!-- Progress -->
					    <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="{{{ item.value }}}" aria-valuemin="0" aria-valuemax="100">
							    <div class="progress-text">
							    	<span {{{ view.getRenderAttributeString( item_label ) }}}>
										{{{ item.label }}}
									</span>
							    	<span {{{ view.getRenderAttributeString( item_value ) }}}>
										{{{ item.value }}}%
									</span>
							    </div>
							</div>
							<div class="progress-text">
								<span {{{ view.getRenderAttributeString( item_label ) }}}>
									{{{ item.label }}}
								</span>
							</div>
                        </div>
                        <# }); #>
					</div>
					<# } #>
                </div>
				
				<# if ( settings.layout_count == '2' ) { #>
			    <div class="col-12<# if ( settings.layout_col == '2' ) { #> col-lg-6 mt-4<# } #> mt-lg-0">
		            <# if ( settings.c2_title ) { #>
		            <{{{ settings.c2_title_tag }}} class="title title--h3">
		            	<span {{{ view.getRenderAttributeString( 'c2_title' ) }}}>
                    		{{{ settings.c2_title }}}
                    	</span>
		            </{{{ settings.c2_title_tag }}}>
		            <# } #>

		            <# if ( settings.c2_items ) { #>
					<div class="box box__second">
					    <# _.each( settings.c2_items, function( item, index ) { 

					    var item_label = view.getRepeaterSettingKey( 'label', 'c2_items', index );
					    view.addInlineEditingAttributes( item_label, 'none' );

					    var item_value = view.getRepeaterSettingKey( 'value', 'c2_items', index );
					    view.addInlineEditingAttributes( item_value, 'none' );

					    #>
					    <!-- Progress -->
					    <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="{{{ item.label }}}" aria-valuemin="0" aria-valuemax="100">
							    <div class="progress-text">
							    	<span {{{ view.getRenderAttributeString( item_label ) }}}>
										{{{ item.label }}}
									</span>
							    	<span {{{ view.getRenderAttributeString( item_value ) }}}>
										{{{ item.value }}}%
									</span>
							    </div>
							</div>
							<div class="progress-text">
								<span {{{ view.getRenderAttributeString( item_label ) }}}>
									{{{ item.label }}}
								</span>
							</div>
                        </div>
                        <# }); #>
					</div>
					<# } #>
                </div>
                <# } #>
			</div>
		</div>

		<?php 
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Vcard_Skills_Widget() );